<html>
<head>
    <title>Petshop Online Pemweb</title>


    <link rel="stylesheet" href="style.css" type="text/css" />
 
</head>
<body>
	<div id="art-page-background-middle-texture">
		<div id="art-main">
			<div class="cleared reset-box"></div>
				<div class="art-box art-sheet">
					<div class="art-box-body art-sheet-body">
						<div class="art-header">
							<div class="art-headerobject"></div>
								<div class="art-logo">
									<h1 class="art-logo-name"><a href="#">Petshop Online Pemweb</a></h1>
									<h2 class="art-logo-text">Tersedia Jenis Kucing Dengan Kualitas Terjamin</h2>
								</div>											
						</div>
							<div class="cleared reset-box"></div>
						<div class="art-bar art-nav">
							<div class="art-nav-outer">
								<ul class="art-hmenu">
									<li>
										<a href="./" class="active">Home</a>
									</li>			
									<li>
										<a href="#">Belanja</a>
											<ul>
												<li><a href='./?pages=viewkeranjang'>Keranjang Belanja</a></li>
												<li><a href='./?pages=viewinvoice'>Invoice</a></li>
												<li><a href='./?pages=viewpromosi'>Promosi</a></li>	
											</ul>
									</li>
									<li>
										<a href="#">Kategori Barang</a>
									</li>	
									<li>
										<a href="./?pages=konfirmasi">Konfirmasi</a>
									</li>			
									<li>
										<a href="#">Tentang Kami</a>
									</li>
								</ul>
							</div>
						</div>
							<div class="cleared reset-box"></div>
								<div class="art-layout-wrapper">
									<div class="art-content-layout">
										<div class="art-content-layout-row">
											<div class="art-layout-cell art-sidebar1">
												<div class="art-box art-block">
													<div class="art-box-body art-block-body">
														<div class="art-bar art-blockheader">
															<h3 class="t">Login Customer</h3>
														</div>
														<div class="art-box art-blockcontent">
														<div class="art-box-body art-blockcontent-body">
															<form action="" method="post" name="login1" id="form-login">
																<fieldset class="input" style="border: 0 none;">
																	<p id="form-login-username">
																		  <label for="modlgn_username">Username</label>
																		  <br />
																		  <input id="modlgn_username" type="text" name="username1" class="inputbox" alt="username" size="18" />
																	</p>
																	<p id="form-login-password">
																		  <label for="modlgn_passwd">Password</label>
																		  <br />
																		  <input id="modlgn_passwd" type="password" name="passwd1" class="inputbox" size="18" alt="password" />
																	</p>
																	<p id="form-login-remember">&nbsp;
																	</p>
																		<span class="art-button-wrapper">
																		  <span class="art-button-l"> </span>
																		  <span class="art-button-r"> </span>
																		  <input type="submit" name="Submit1" class="art-button" value="Login" />
																		</span>
																</fieldset>
																  <ul>
																	<li>
																	  <a href="./?pages=register">Create an account</a>
																	</li>
																  </ul>
															</form>                
																<div class="cleared"></div>
														</div>
														</div>
															<div class="cleared"></div>
													</div>
												</div>
													<div class="art-box art-block">
														<div class="art-box-body art-block-body">
															<div class="art-bar art-blockheader">
																<h3 class="t">Kucing Populer</h3>
															</div>
															 <div class="art-box art-blockcontent">
																<div class="art-box-body art-blockcontent-body">
																	<ul>
																		<li><a href='./?pages=viewkeranjang'>Persia Betina</a></li>
																		<li><a href='./?pages=viewinvoice'>Persia Jantan</a></li>
																		<li><a href='./?pages=viewkeranjang'>Mainecoon Betina</a></li>
																		<li><a href='./?pages=viewinvoice'>Mainecoon Jantan</a></li>
																	
																	</ul>                
																<div class="cleared"></div>
																</div>
															</div>
																<div class="cleared"></div>
														</div>
													</div>
												<div class="cleared"></div>
											</div>
												<div class="art-layout-cell art-content">
													<div class="art-box art-post">
														<div class="art-box-body art-post-body">
															<div class="art-post-inner art-article">
																<div class="art-postcontent">
																	<div class="main_content">
																		<div class="panel_persiabetina">							
																			<div class="menu_content"></div>
																				<div class="judul_content">
																						<ul>
																							<li><a>Persia Betina</a></li>
																						</ul>
																				</div>
																		</div>						
																		<div class="panel_persiajantan">
																		<div class="menu_content2"></div>
																					<div class="judul_content2">
																						<ul>
																							<li><a>Persia Jantan</a></li>
																						</ul>
																					</div>
																				</div>
																				
																				<div class="panel_mainecoonbetina">							
																					<div class="menu_content3"></div>
																					<div class="judul_content3">
																						<ul>
																							<li><a>Mainecoon Betina</a></li>
																						</ul>
																					</div>
																				</div>
																				
																				<div class="panel_mainecoonjantan">
																					<div class="menu_content4"></div>
																					<div class="judul_content4">
																						<ul>
																							<li><a>Mainecoon Jantan</a></li>
																						</ul>
																					</div>
																				</div>
																	</div>	
																</div>
																<div class="cleared"></div>
															</div>

																<div class="cleared"></div>
															</div>
														</div>
														<div class="art-box art-post">
															<div class="art-box-body art-post-body">
														<div class="art-post-inner art-article">
																		<div class="art-postcontent">
															<TABLE width="100%" border="0">
															<tr>
																<td colspan='4'><h2>Jasa Pengiriman dan Pembayaran</h2><img src='images/JasaPengiriman.png' height="60" width="314">&nbsp;&nbsp;<img src='images/PayPal.png' height="40"></td>
															</tr>
															</TABLE>


																		</div>
																		<div class="cleared"></div>
																		</div>

																<div class="cleared"></div>
															</div>
														</div>

																				  <div class="cleared"></div>
																				</div>
																				<div class="art-layout-cell art-sidebar2">
														<div class="art-box art-block">
															<div class="art-box-body art-block-body">
																		<div class="art-bar art-blockheader">
																			<h3 class="t">Belanja</h3>
																		</div>
																		<div class="art-box art-blockcontent">
																			<div class="art-box-body art-blockcontent-body">
																		<ul>
																			<li><a href='./?pages=viewkeranjang'>Keranjang Belanja</a></li>
																			<li><a href='./?pages=viewinvoice'>Invoice</a></li>
																			<li><a href='./?pages=viewpromosi'>Promosi</a></li>
																			<li><a href="./?pages=konfirmasi">Konfirmasi</a></li>
																		</ul>                
																								<div class="cleared"></div>
																			</div>
																		</div>
																<div class="cleared"></div>
															</div>
														</div>

														<div class="art-box art-block">
															<div class="art-box-body art-block-body">
																		<div class="art-bar art-blockheader">
																			<h3 class="t">Pembayaran</h3>
																		</div>
																		<div class="art-box art-blockcontent">
																			<div class="art-box-body art-blockcontent-body">
																<div class="bannergroup_text">
																		<img src='images/sbca.png'><br>0321670022 a.n Pemweb<br>
																		<img src='images/smandiri.png'><br>1110006039813 a.n Pemweb<br>
																		<img src='images/sbri.png'><br>0669.01.004717.452 a.n Pemweb<br>
																		<img src='images/sbni.png'><br>0669.01.004718.116 a.n Pemweb<br>
																</div>                
																								<div class="cleared"></div>
																			</div>
																		</div>
																<div class="cleared"></div>
															</div>
														</div>


																				  <div class="cleared"></div>
											</div>
										</div>
									</div>
								</div>
									<div class="cleared"></div>
										<div class="art-footer">
											<div class="art-footer-body">

														<div class="art-footer-text">
														   <p>Copyright &copy;  2016 Pemweb. All rights reserved.</p>
															<div class="cleared"></div>
															<p class="art-page-footer">&nbsp;</p>
														</div>
												<div class="cleared"></div>
											</div>
										</div>
								<div class="cleared"></div>
					</div>
				</div>
					<div class="cleared"></div>
		</div>
	</div>
</body>
</html>
